"""Compare adapter behavior with native mini/CLIs, then exercise the native runner."""
import json
import os
import shlex
import subprocess
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import litellm

from minisweagent.exceptions import FormatError
from minisweagent.config import get_config_from_spec
from minisweagent.models.litellm_model import LitellmModel
from minisweagent.models.utils.actions_toolcall import parse_toolcall_actions
from minisweagent.run.benchmarks.aci import patch_command
from minisweagent.run.benchmarks.aci_staged import (
    DEFINITIONS, StagedModel, cli_command, schema, test_command as make_test_command,
)
from tests.aci import test_native_replay

ROOT = test_native_replay.ROOT


def response(name, arguments):
    return litellm.ModelResponse(choices=[{"index": 0, "finish_reason": "tool_calls", "message": {
        "role": "assistant", "content": "Fixture", "tool_calls": [{"id": "call_fixture", "type": "function",
        "function": {"name": name, "arguments": json.dumps(arguments)}}]}}])


class StagedBoundaryTests(unittest.TestCase):
    def test_native_format_template_context_and_truncation_guidance_are_preserved(self):
        template = '{{finish_reason}}|{{has_tool_calls}}|{{actions}}|{{error}}'
        empty = litellm.ModelResponse(choices=[{'index': 0, 'finish_reason': 'length',
            'message': {'role': 'assistant', 'content': 'Incomplete'}}])
        for model_type in (LitellmModel, StagedModel):
            with self.assertRaises(FormatError) as error:
                model_type(model_name='openai/fixture', format_error_template=template)._parse_actions(empty)
            self.assertTrue(error.exception.messages[0]['content'].startswith('length|False|[]|'))
        native = get_config_from_spec('swebench.yaml')['model']['format_error_template']
        staged = get_config_from_spec('aci-staged.yaml')['model']['format_error_template']
        messages = []
        for model_type, prompt in ((LitellmModel, native), (StagedModel, staged)):
            with self.assertRaises(FormatError) as error:
                model_type(model_name='openai/fixture', format_error_template=prompt)._parse_actions(empty)
            messages.append(error.exception.messages[0]['content'])
        self.assertEqual(messages[0].replace('bash tool call', 'available named tool call'), messages[1])

    def test_upstream_metadata_is_unchanged_and_all_search_api_arguments_are_reused(self):
        for source, copied in (
            ('external/CodeStruct/SWE-agent/tools/ast_read/config.yaml', 'tools/understanding/codestruct/upstream/CodeStruct/SWE-agent/tools/ast_read/config.yaml'),
            ('external/CodeStruct/SWE-agent/tools/ast_edit/config.yaml', 'tools/editing/upstream/ast_edit.yaml'),
            ('external/CodeStruct/SWE-agent/tools/str_replace/config.yaml', 'tools/editing/upstream/str_replace.yaml'),
        ):
            self.assertEqual((ROOT / source).read_bytes(), (ROOT / copied).read_bytes())
        self.assertEqual({name for name, value in DEFINITIONS.items() if value['stage'] == 'S'},
                         {path.name for path in (ROOT / 'tools/search/bin').iterdir()})
        self.assertEqual(schema('get_code_around_line')['function']['parameters']['required'],
                         ['file_name', 'line_no_str', 'window_size_str'])

    def test_required_field_extraction_matches_mini_instead_of_rejecting_extra_metadata(self):
        extras = {'unused': 1, 'file_path': '/tmp/unused'}
        original = parse_toolcall_actions(response('bash', {'command': 'pwd', **extras}).choices[0].message.tool_calls,
                                          format_error_template='{{error}}')
        self.assertEqual(original, [{'command': 'pwd', 'tool_call_id': 'call_fixture'}])
        model = StagedModel(model_name='openai/fixture')
        for name, args in [('search_method', {'method_name': 'add'}), ('view_diff', {}), ('submit', {})]:
            action, = model._parse_actions(response(name, args | extras | {'command': 'touch /tmp/aci-shell-escape'}))
            self.assertEqual(action['arguments'], args)
            self.assertNotIn('aci-shell-escape', action.get('command', ''))
        for name, args in [('bash', {'command': 'pwd'}), ('search_method', {}), ('submit', []), ('submit', None)]:
            with self.assertRaises(FormatError):
                model._parse_actions(response(name, args))
        multiple = response('search_method', {'method_name': 'add'})
        multiple.choices[0].message.tool_calls *= 2
        with self.assertRaises(FormatError):
            model._parse_actions(multiple)

    def test_initial_stages_remain_but_common_operations_and_returning_to_editing_are_available(self):
        model = StagedModel(model_name='openai/fixture')
        for stage in ('S', 'U', 'E'):
            model.stage = stage
            self.assertTrue({'view_diff', 'submit', 'run_tests'} <= set(model.available_names()))
        self.assertNotIn('readCode', model.available_names())
        self.assertNotIn('editCode', model.available_names())
        model.started_search = True
        self.assertIn('readCode', model.available_names())
        self.assertNotIn('editCode', model.available_names())
        model.started_reading = True
        model.stage = 'S'
        self.assertIn('editCode', model.available_names())
        model._parse_actions(response('editCode', {'path': 'a.py', 'operation': 'delete_node', 'selector': 'add'}))

    def test_cli_arguments_preserve_native_paths_numeric_strings_nulls_and_literal_text(self):
        model = StagedModel(model_name='openai/fixture')
        model.started_search = model.started_reading = True
        action, = model._parse_actions(response('readCode', {'path': '../testbed/mathops.py',
            'line_start': '1', 'line_end': 4, 'selector': None, 'unused': 'ignored'}))
        self.assertEqual(shlex.split(action['command'])[1:],
                         ['/root/aci-tools/understanding/bin/readCode', '--selector=', '--line-start=1', '--line-end=4', '--', '../testbed/mathops.py'])
        literal = '$(touch /tmp/aci-shell-escape) `touch /tmp/aci-shell-escape`'
        for path in ('tests/test_new.py', 'conftest.py', '/tmp/reproduce.py', 'symlink.txt'):
            argv = shlex.split(cli_command('create_file', {'file_path': path, 'content': literal}))
            self.assertEqual(argv[-2:], [path, literal])
        from swebench.harness.constants.python import TEST_DJANGO, TEST_PYTEST
        self.assertEqual(shlex.split(make_test_command([])), ['exec', *shlex.split(TEST_PYTEST)])
        self.assertEqual(shlex.split(make_test_command([], django=True)), ['exec', *shlex.split(TEST_DJANGO)])
        self.assertEqual(shlex.split(make_test_command('new_test.py'))[-1], 'new_test.py')
        self.assertEqual(shlex.split(make_test_command(['-k', 'addition', 'tests']))[-3:], ['-k', 'addition', 'tests'])
        self.assertEqual(shlex.split(make_test_command(['migrations', '--verbosity=2'], django=True))[-2:],
                         ['migrations', '--verbosity=2'])


@unittest.skipUnless(os.environ.get('ACI_NATIVE_REPLAY'), 'Set ACI_NATIVE_REPLAY=1 for Docker integration')
class StagedReplayTests(unittest.TestCase):
    fixture = test_native_replay.NativeReplayTests.fixture

    def test_native_cli_paths_tests_returning_stages_selected_submission_and_resume(self):
        literal = "--help\n$(touch /tmp/aci-shell-escape) `touch /tmp/aci-shell-escape` ' quoted"
        sequence = [
            ('view_diff', {'command': 'touch /tmp/aci-shell-escape'}),
            ('run_tests', {'targets': {'not': 'a runner argument'}}),
            ('run_tests', {'targets': ['test_mathops.py']}),
            ('search_method', {'method_name': 'add', 'unused': 'ignored'}),
            ('readCode', {'path': 'mathops.py', 'line_start': '1', 'line_end': '6'}),
            ('bash', {'command': 'touch /tmp/aci-shell-escape'}),
            ('create_file', {'file_path': '/tmp/aci-native-path.txt', 'content': literal}),
            ('create_file', {'file_path': 'symlink.txt', 'content': 'native symlink writes allowed'}),
            ('editCode', {'path': 'mathops.py', 'operation': 'replace_node', 'selector': 'add',
                          'replacement': 'def add(a, b):\n    """éé 합계"""\n    return a + b'}),
            ('search_method', {'method_name': 'add'}),
            ('str_replace', {'file_path': 'mathops.py', 'old_str': 'éé 합계', 'new_str': '합계'}),
            ('create_file', {'file_path': 'test_extra.py', 'content': 'from mathops import add\ndef test_extra():\n    assert add(4, 5) == 9\n'}),
            ('str_replace', {'file_path': 'test_mathops.py', 'old_str': 'add(2, 3) == 5', 'new_str': 'add(3, 4) == 7'}),
            ('run_tests', {'targets': 'test_mathops.py'}),
            ('run_tests', {'targets': ['test_extra.py', '-k', 'extra']}),
            ('readCode', {'path': '/tmp/aci-native-path.txt'}),
            ('readCode', {'path': 'symlink.txt'}),
            ('search_method', {'method_name': 'add'}),
            ('view_diff', {'paths': ['mathops.py'], 'command': 'touch /tmp/aci-shell-escape'}),
            ('run_tests', {'targets': ['test_mathops.py', 'test_extra.py']}),
            ('submit', {'paths': ['mathops.py'], 'parameters': {}, 'command': 'touch /tmp/aci-shell-escape'}),
        ]
        payloads = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass
            def do_POST(self):
                payloads.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
                name, args = sequence[min(len(payloads) - 1, len(sequence) - 1)]
                result = response(name, args).model_dump()
                result.update(model='fixture', usage={'prompt_tokens': 10, 'completion_tokens': 10, 'total_tokens': 20})
                body = json.dumps(result).encode()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        traces, command, output, log = self.fixture([], condition='sue', staged=True, seconds=60, model={
            'model_class': 'minisweagent.run.benchmarks.aci_staged.StagedModel',
            'model_name': 'openai/fixture', 'cost_tracking': 'ignore_errors',
            'model_kwargs': {'api_base': f'http://127.0.0.1:{server.server_port}/v1', 'api_key': 'EMPTY'}})
        trace = traces[0]
        self.assertEqual(trace['info']['exit_status'], 'Submitted', log)
        self.assertEqual(len(payloads), len(sequence), log)
        self.assertTrue(all('bash' not in [tool['function']['name'] for tool in payload['tools']] for payload in payloads))
        self.assertTrue(all(payload.get('parallel_tool_calls') is False for payload in payloads))
        errors = [m for m in trace['messages'] if m.get('extra', {}).get('interrupt_type') == 'FormatError']
        self.assertEqual(len(errors), 1)  # Only the explicitly unsupported shell call.
        observations = [m for m in trace['messages'] if m['role'] == 'tool']
        tests = [m for m in observations if m['extra']['tool'] == 'run_tests']
        self.assertEqual(tests[0]['extra']['returncode'], 64)
        self.assertIn('1 failed', tests[1]['content'])
        self.assertTrue(all('1 passed' in m['content'] for m in tests[2:4]))
        self.assertIn('2 passed', tests[-1]['content'])
        self.assertTrue(all(m['extra']['returncode'] == 0 for m in observations if m['extra']['tool'] == 'create_file'))
        reads = [m['content'] for m in observations if m['extra']['tool'] == 'readCode']
        self.assertIn(literal, reads[-2])
        self.assertIn('native symlink writes allowed', reads[-1])
        patch = trace['info']['submission']
        self.assertIn('+    return a + b', patch)
        self.assertEqual(patch.count('diff --git'), 1)
        self.assertNotIn('test_extra.py', patch)
        self.assertNotIn('test_mathops.py', patch)
        actions = [a for m in trace['messages'] for a in m.get('extra', {}).get('actions', [])]
        returned_edit = next(a for a in actions if a['tool'] == 'str_replace')
        self.assertEqual(returned_edit['stage_before'], 'S')
        controls = [a for a in actions if a['tool'] in {'view_diff', 'submit', 'run_tests'}]
        self.assertTrue(all(a['stage_before'] == a['stage_after'] for a in controls))
        self.assertEqual([a['stage_after'] for a in controls], ['S', 'S', 'S', 'E', 'E', 'S', 'S', 'S'])
        self.assertEqual(controls[-1]['command'], patch_command(['mathops.py']))
        saved = (output / 'fixture-0/fixture-0.traj.json').read_bytes()
        resumed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=45)
        self.assertEqual(resumed.returncode, 0, resumed.stdout + resumed.stderr)
        self.assertEqual(saved, (output / 'fixture-0/fixture-0.traj.json').read_bytes())
        self.assertEqual(len(payloads), len(sequence))
