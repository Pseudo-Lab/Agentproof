"""Bind strict deadlines and patch recovery to mini's unchanged batch CLI.

Mini owns the loop, prompts, parsing, accounting, files and resume. Its native
wall limit only checks between turns. AnyIO bounds the library request; GNU
timeout bounds the command inside Docker, including child processes.
"""
import asyncio
import logging
import shlex
import time

import litellm
from anyio import fail_after
from anyio.from_thread import BlockingPortalProvider
from tenacity import AsyncRetrying
from minisweagent.exceptions import Submitted, TimeExceeded
from minisweagent.models.litellm_model import LitellmModel
from minisweagent.models.utils.actions_toolcall import BASH_TOOL
from minisweagent.models.utils.retry import retry
from minisweagent.run.benchmarks import swebench
from minisweagent.run.benchmarks.utils.common import ProgressTrackingAgent


def patch_command(paths=None):
    """Native git path selection, shared by submission and deadline recovery."""
    paths = paths if isinstance(paths, list) else [paths] if paths is not None else []
    return "git add -N . && git diff --binary HEAD -- " + shlex.join([*(paths or ["."]), ":!patch.txt"])


def time_exceeded():
    return TimeExceeded({"role": "exit", "content": "TimeExceeded",
                         "extra": {"exit_status": "TimeExceeded", "submission": ""}})


class DeadlineModel(LitellmModel):
    # Native query owns parsing/accounting; move its retry policy inside the
    # cancellable async deadline so retry sleeps cannot extend the budget.
    abort_exceptions = [BaseException]
    deadline = float("inf")
    portal_provider = BlockingPortalProvider()

    def _query(self, messages, **kwargs):
        async def request():
            remaining = self.deadline - time.monotonic()
            if remaining <= 0:
                raise time_exceeded()
            try:
                with fail_after(remaining) as deadline_scope:
                    policy = retry(logger=logging.getLogger("litellm_model"),
                                   abort_exceptions=[*LitellmModel.abort_exceptions, asyncio.CancelledError])
                    async for attempt in AsyncRetrying(retry=policy.retry, wait=policy.wait, stop=policy.stop,
                                                       before_sleep=policy.before_sleep, reraise=policy.reraise):
                        with attempt:
                            return await litellm.acompletion(
                                model=self.config.model_name, messages=messages,
                                **({"tools": [BASH_TOOL]} | self.config.model_kwargs | kwargs),
                            )
            except TimeoutError:
                if not deadline_scope.cancel_called:
                    raise
                raise time_exceeded() from None
            except litellm.exceptions.AuthenticationError as error:
                # Preserve the original LiteLLM model's configuration guidance.
                error.message += " You can permanently set your API key with `mini-extra config set KEY VALUE`."
                raise
        with self.portal_provider as portal:
            return portal.call(request)


class DeadlineEnvironment:
    """Delegate to the native Docker environment; bound its interpreter only."""
    def __init__(self, environment, deadline):
        self.environment = environment
        self.deadline = deadline

    def __getattr__(self, name):
        return getattr(self.environment, name)

    def execute(self, action):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise time_exceeded()
        limit = min(remaining, self.config.timeout)
        original = self.config.interpreter
        self.config.interpreter = ["timeout", "--signal=KILL", f"{limit:.6f}", *original]
        try:
            # Work ends at limit; grace only collects the killed command's output.
            result = self.environment.execute(action, timeout=limit + 2)
        except Submitted:
            if time.monotonic() >= self.deadline:
                raise time_exceeded() from None
            raise
        finally:
            self.config.interpreter = original
        if time.monotonic() >= self.deadline:
            raise time_exceeded()
        return result


class BudgetAgent(ProgressTrackingAgent):
    def run(self, task="", **kwargs):
        self._start_time = time.time()
        seconds = self.config.wall_time_limit_seconds
        deadline = time.monotonic() + seconds if seconds else float("inf")
        self.model.deadline = deadline
        original_env = self.env
        self.env = DeadlineEnvironment(original_env, deadline)
        try:
            try:
                info = super().run(task, **kwargs)
            finally:
                # Persist mini's existing timer before recovery and cleanup.
                if self.messages and self.messages[-1].get("role") == "exit":
                    self.messages[-1].setdefault("extra", {})["elapsed_seconds"] = (
                        self.get_template_vars()["elapsed_seconds"]
                    )
            if info.get("exit_status") in {"TimeExceeded", "LimitsExceeded"}:
                # Include new nonignored files; exclude mini's patch output artifact.
                result = original_env.execute({"command": patch_command()}, timeout=30)
                if result["returncode"] != 0:
                    raise RuntimeError(f"Could not recover patch after budget exhaustion: {result['output']}")
                info.update(submission=result["output"], autosubmitted=True)
            return info
        finally:
            self.env = original_env
            # Native batch relies on __del__; retained references can keep its last container alive.
            original_env.cleanup()


def main():
    # The native batch script fixes its agent class internally. Bind that class;
    # leave its CLI, dataset loading, workers and persistence intact.
    original = swebench.ProgressTrackingAgent
    swebench.ProgressTrackingAgent = BudgetAgent
    try:
        # The configured model is imported by its canonical module, even under -m.
        from minisweagent.run.benchmarks.aci import DeadlineModel as ConfiguredModel
        with ConfiguredModel.portal_provider:
            swebench.app()
    finally:
        swebench.ProgressTrackingAgent = original


if __name__ == "__main__":
    main()
