# ACI-Lens

목표는 **mini-swe-agent에서 최소 수정으로 우리 방법론을 다루는 것**이다.
최소 수정에는 디렉토리 구성도 포함한다. 기존 프로젝트 구조·runner·설정 기능을 우선 활용한다.

mini-swe-agent 위에서 Search / Understanding / Editing 도구의 해결률과 효율을 비교한다.
실행 루프·모델 응답 처리·설정 병합·배치·재개·결과 저장은 mini 원본을 사용하고,
최종 평가는 공식 SWE-bench로 수행한다. 모델은 mini의 bash를 통해 설치된 도구를 호출한다.

mini 2.4.6 (`04d809ceab9df28f9adaed044884180159172930`)의 `src/minisweagent/`와
원본 테스트를 가져왔다. 원본 파일은 변경하지 않고 연구용 실행 연결과 설정을 추가했다.
출처와 추가 코드의 필요성은 [원본 대비 변경](docs/upstream-reuse.md)에 기록한다.

## 구조

```text
src/minisweagent/
  agents/                   원본 에이전트 루프
  environments/             원본 실행 환경
  models/                   원본 모델 연결
  run/benchmarks/
    swebench.py             원본 배치 CLI
    aci.py                  엄격한 600초 종료·중간 패치 회수 연결
    export_dataset.py       고정 revision·문제 목록과 gold 분리
  config/
    extra/                  aci-*, model-*, endpoint-*, serve-* 설정
    datasets/               고정 데이터와 문제 목록
    upstreams.lock.json     원본 커밋
tools/
  search/                  AutoCodeRover 검색 backend + CLI 연결
  understanding/
    codestruct/            CodeStruct readCode (기본 U)
    agentless/             Agentless skeleton 함수 + CLI (대체 U)
  editing/                 CodeStruct editCode, str_replace, create_file
tests/                     원본 mini 테스트; 연구 연결 검사는 aci/
results/<실험명>/            원본 예측·trajectory·평가 결과
docs/                      설계·분석·출처
environments/serve/        별도 vLLM 환경
pyproject.toml, uv.lock    실행·평가 환경
```

`external/`는 원본 비교·평가용 checkout, `data/`는 준비한 입력, `models/`는 로컬 가중치다.
새 실행 코드는 `results/`에 만들지 않는다. 과거 결과와 실행 당시 코드 사본은 보존한다.

## 설치

프로젝트 루트에서 실행한다. 평가용 checkout이 이미 고정되어 있으면 clone은 생략한다.

```bash
git clone https://github.com/SWE-bench/SWE-bench.git external/SWE-bench
git -C external/SWE-bench checkout --detach 726c5461e2ef52d83cf1ea2107870a8bb3328d57
uv sync --locked --extra research
mkdir -p .cache/aci-bin
cp "$(command -v uv)" .cache/aci-bin/uv
```

S/U/E는 mini의 `run.env_startup_command`가 선택된 도구만 컨테이너에 설치한다.
도구 의존성은 private venv에 두며 benchmark Python은 유지한다. S 인덱스는 준비 단계에서
만들고 파일이 바뀌면 갱신한다. 준비 시간은 600초 작업 예산 밖이다.

## 비교할 도구

S/U/E는 우리가 비교하는 인터페이스의 역할이다. 기존 연구의 도구를 재사용하며,
각 연구의 전체 에이전트나 실행 절차를 재현했다고 부르지 않는다.

| 역할 | 구현 | mini의 bash에서 호출하는 명령 |
| --- | --- | --- |
| S: 검색 | AutoCodeRover SearchBackend | `search_method`, `search_class`, `search_code` 등 원본 API 8개 |
| U: 읽기 | CodeStruct (기본) | `readCode PATH`, `readCode PATH --selector NAME` |
| U: 구조 요약 | Agentless (대체) | `agentless_skeleton FILE_PATH` |
| E: 수정 | CodeStruct | `str_replace PATH OLD_TEXT NEW_TEXT`, `editCode PATH OPERATION SELECTOR`, `create_file PATH CONTENT` |

원본 알고리즘과 출력 방식을 유지한다. 예외는 재현·기록한 CodeStruct
[readCode](tools/understanding/codestruct/patches/README.md)와
[editCode](tools/editing/patches/README.md)의 UTF-8 위치 오류 수정이다.
`str_replace`와 `create_file`은 원본 그대로다. 출처·라이선스도 함께 보존한다.

## 입력 준비

```bash
uv run --locked --extra research python -m minisweagent.run.benchmarks.export_dataset \
  src/minisweagent/config/datasets/swe-lite-50.json \
  data/instances/mini-swe-lite-50 data/evaluator/mini-swe-lite-50.json
```

에이전트 입력에는 instance_id, repo, problem_statement, base_commit만 저장한다.
gold 패치와 공식 테스트 정보는 별도 평가 입력에만 둔다.

## 모델 서버

물리 GPU 2·3만 사용한다. 서버 환경은 실행·평가 환경과 분리한다.

```bash
uv sync --locked --project environments/serve
unset CUDA_VISIBLE_DEVICES
VLLM_CACHE_ROOT="$PWD/.cache/vllm-physical-gpu2" \
  uv run --no-sync --project environments/serve vllm serve models/gemma-4-31B-it \
  --config src/minisweagent/config/extra/serve-gemma31b.yaml --device-ids 2 --port 18002
```

GPU 3에는 `--device-ids 3 --port 18003`과 별도 cache를 사용한다.

## 실행

mini의 반복 `-c`와 원본 배치 CLI를 사용한다. 별도 실험 루프는 없다.

```bash
export OPENAI_API_KEY=EMPTY
uv run --locked --extra research python -m minisweagent.run.benchmarks.aci \
  --subset data/instances/mini-swe-lite-50 --split test --workers 1 \
  -c swebench.yaml -c aci-common.yaml -c model-gemma4-31b.yaml \
  -c aci-sue.yaml -c aci-tool-first.yaml -c endpoint-gpu2.yaml -c aci-wall600.yaml \
  -o results/mini-gemma31b-sue-codestruct-tool-first-t600-seed42
```

조건은 baseline, s, u, e, su, se, ue, sue다. U의 기본 구현은 CodeStruct다.
Agentless U는 `aci-u-agentless.yaml`, `aci-su-agentless.yaml`,
`aci-ue-agentless.yaml`, `aci-sue-agentless.yaml` 중 해당 조건으로 교체한다.
설정이 바뀌면 새 출력 디렉토리를 쓴다.
같은 출력 경로로 재실행하면 mini가 `preds.json`의 기존 문제를 건너뛴다.
원본의 부드러운 시간 제한만 필요하면 `mini-extra swebench`를 직접 사용할 수 있다.

600초에는 모델 요청과 도구 실행이 포함된다. 요청·도구 호출 수와 비용 상한은 없고,
모델에게 남은 시간을 알리지 않는다. 진행 중 요청 취소와 명령 종료 후 최대 30초 동안
중간 패치를 회수한다. 상세 범위와 한계는 [실행 연결](docs/implementation.md)을 따른다.

위 명령의 `aci-tool-first.yaml`은 해당 작업에서 **제공한 도구를 먼저 사용하도록 안내**한다.
CodeStruct U는 먼저 파일을 읽고, 요약만 나오면 필요한 심볼·줄 범위를 요청한다.
Agentless U는 먼저 구조를 보고 필요한 본문을 셸로 읽는다. E는 작은 수정에
`str_replace`, 함수·클래스 수정에 `editCode`, 파일 생성에 `create_file`을 안내한다.
지원하지 않거나 실패한 작업에는 일반 셸을 사용할 수 있다. 별도 function tool,
셸 명령 치환, 고정 S→U→E 순서나 사용 강제는 추가하지 않는다.

같은 도구에서 사용 안내의 효과를 비교하려면 `-c aci-tool-first.yaml`만 뺀다.
이때 설치 도구·모델·runner·예산은 같다. 실제 사용 여부는 후속 실험의 trajectory로
검증해야 하며, 이 설정만으로 항상 사용한다고 가정하지 않는다.

## 공식 평가

배치 종료 후 공식 CLI를 별도로 실행한다. 공식 파일명과 결과 형식을 유지한다.

```bash
(
  aci_project_root="$PWD"
  mkdir -p results/mini-gemma31b-sue-codestruct-tool-first-t600-seed42/evaluation
  cd results/mini-gemma31b-sue-codestruct-tool-first-t600-seed42/evaluation
  "$aci_project_root/.venv/bin/python" -m swebench.harness.run_evaluation \
    --dataset_name "$aci_project_root/data/evaluator/mini-swe-lite-50.json" \
    --predictions_path "$aci_project_root/results/mini-gemma31b-sue-codestruct-tool-first-t600-seed42/preds.json" \
    --run_id mini-gemma31b-sue-codestruct-tool-first-t600-seed42
)
```

## 검사

도구의 원본 출력 비교에는 lock에 기록된 `external/auto-code-rover`, `external/Agentless`,
`external/CodeStruct` checkout을 사용한다. 검사는 실제 모델을 호출하지 않는다.

```bash
aci_test_dir=$(mktemp -d)
cp -a tools "$aci_test_dir/tools"
for tool in search understanding/codestruct understanding/agentless editing; do
  bash "$aci_test_dir/tools/$tool/install.sh"
done
ACI_TEST_BUNDLES="$aci_test_dir/tools" \
  uv run --locked --extra research python -m unittest discover -s tests/aci -v

docker build -f containers/smoke.Dockerfile -t aci-lens-smoke:mini-20261025 .
ACI_NATIVE_REPLAY=1 \
  uv run --locked --extra research python -m unittest discover -s tests/aci -p test_native_replay.py -v

uv run --locked --extra research pytest tests/config tests/utils tests/agents/test_default.py -q
```

이전 Agentless pilot과 분석은 [과거 실험 기록](docs/agentless-pilot.md)에 남아 있다.
이번 구조 정리 전 소스·설정은 `results/mini-structure-20261026/before.tar.gz`에 보존했다.
과거 결과는 새 mini 비교와 합치지 않는다. 연구 실험은 사용자가 재개할 때까지 중단 상태다.
